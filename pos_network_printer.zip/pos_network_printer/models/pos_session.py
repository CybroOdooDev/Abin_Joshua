# -- coding: utf-8 --
#############################################################################
#
#    Cybrosys Technologies Pvt. Ltd.
#
#    Copyright (C) 2026-TODAY Cybrosys Technologies(<https://www.cybrosys.com>)
#    Author: Cybrosys Techno Solutions(<https://www.cybrosys.com>)
#
#    You can modify it under the terms of the GNU LESSER
#    GENERAL PUBLIC LICENSE (LGPL v3), Version 3.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU LESSER GENERAL PUBLIC LICENSE (LGPL v3) for more details.
#
#    You should have received a copy of the GNU LESSER GENERAL PUBLIC LICENSE
#    (LGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
#############################################################################
import logging
from odoo import api, fields, models, _

_logger = logging.getLogger(__name__)


class PosSession(models.Model):
    _inherit = 'pos.session'

    def get_cash_closing_report_data(self):
        """
        Calculates and returns complete summary data for the Cash Closing Report.
        Compatible with CashSecurity module which automatically populates
        cash_register_balance_start and cash_register_balance_end_real.
        """
        self.ensure_one()

        orders = self.order_ids.filtered(lambda o: o.state in ['paid', 'done', 'invoiced'])
        currency = self.currency_id

        # 1. Dynamic Payment Methods (All configured in POS config)
        configured_payment_methods = self.config_id.payment_method_ids
        all_payments = orders.payment_ids

        payment_methods_summary = []
        for pm in configured_payment_methods:
            pm_payments = all_payments.filtered(lambda p: p.payment_method_id == pm)
            amount = sum(pm_payments.mapped('amount'))
            count = len(pm_payments)
            is_cash = bool(pm.type == 'cash' or pm.is_cash_count)
            payment_methods_summary.append({
                'id': pm.id,
                'name': pm.name,
                'type': pm.type,
                'is_cash': is_cash,
                'amount': amount,
                'count': count,
            })

        # 2. Total Sales and Tax Breakdown
        gross_sales = sum(orders.mapped('amount_total'))
        tax_total = sum(orders.mapped('amount_tax'))
        net_sales = gross_sales - tax_total

        # 3. Cash Drawer Balance & Cash Movements (CashSecurity Compatibility)
        opening_cash = self.cash_register_balance_start or 0.0

        cash_pm_ids = configured_payment_methods.filtered(lambda pm: pm.type == 'cash' or pm.is_cash_count).ids
        cash_payments = all_payments.filtered(lambda p: p.payment_method_id.id in cash_pm_ids)
        cash_sales = sum(cash_payments.mapped('amount'))

        # Cash In / Cash Out movements (manual cash in/out moves)
        cash_in = 0.0
        cash_out = 0.0
        moves_list = []
        prefix = f"{self.name}-"
        manual_moves = self.sudo().statement_line_ids.filtered(
            lambda l: bool(l.payment_ref and l.payment_ref.startswith(prefix))
        ).sorted('create_date')

        for move in manual_moves:
            move_amount = move.amount
            if move_amount >= 0:
                cash_in += move_amount
            else:
                cash_out += abs(move_amount)

            moves_list.append({
                'id': move.id,
                'name': move.payment_ref or (_('Cash In') if move_amount >= 0 else _('Cash Out')),
                'amount': move_amount,
                'date': fields.Datetime.to_string(move.create_date) if move.create_date else False,
            })

        net_cash_moves = cash_in - cash_out
        if self.state == 'closed':
            if abs(net_cash_moves - (self.cash_real_transaction or 0.0)) > 0.001:
                _logger.warning(
                    "Session %s: Net manual cash movements (%s) differ from cash_real_transaction (%s)",
                    self.name, net_cash_moves, self.cash_real_transaction
                )
        expected_cash = opening_cash + cash_sales + net_cash_moves
        counted_cash = self.cash_register_balance_end_real or 0.0
        difference = counted_cash - expected_cash

        # Company details
        company = self.company_id
        street_parts = [p for p in [company.street, company.street2] if p]
        city_parts = [p for p in [company.city, company.zip] if p]
        company_address_parts = [p for p in [company.street, company.street2, company.city, company.zip] if p]

        start_at_str = fields.Datetime.context_timestamp(self, self.start_at).strftime('%d/%m/%Y %H:%M') if self.start_at else '-'
        stop_at_str = fields.Datetime.context_timestamp(self, self.stop_at or fields.Datetime.now()).strftime('%d/%m/%Y %H:%M')

        return {
            'session': {
                'id': self.id,
                'name': self.name,
                'pos_name': self.config_id.name,
                'cashier': self.user_id.name,
                'start_at': start_at_str,
                'stop_at': stop_at_str,
                'state': self.state,
                'printer_type': self.config_id.cash_closing_printer_type,
            },
            'company': {
                'name': company.name,
                'vat': company.vat or '',
                'street': ', '.join(street_parts),
                'city_zip': ', '.join(city_parts),
                'address': ', '.join(company_address_parts),
                'phone': company.phone or '',
                'email': company.email or '',
            },
            'currency': {
                'symbol': currency.symbol,
                'position': currency.position,
                'decimals': currency.decimal_places or 2,
            },
            'sales_summary': {
                'total_orders': len(orders),
                'net_sales': net_sales,
                'tax_total': tax_total,
                'gross_sales': gross_sales,
            },
            'payment_methods': payment_methods_summary,
            'cash_details': {
                'opening_cash': opening_cash,
                'cash_sales': cash_sales,
                'cash_in': cash_in,
                'cash_out': cash_out,
                'net_cash_moves': net_cash_moves,
                'expected_cash': expected_cash,
                'counted_cash': counted_cash,
                'difference': difference,
                'moves': moves_list,
            },
        }

    closing_ticket_ids = fields.One2many(
        'pos.printed.ticket',
        'session_id',
        string='Printed Ticket History',
    )
    closing_ticket_count = fields.Integer(
        string='Tickets Count',
        compute='_compute_closing_ticket_count',
    )

    @api.depends('closing_ticket_ids')
    def _compute_closing_ticket_count(self):
        for session in self:
            session.closing_ticket_count = len(session.closing_ticket_ids)

    @api.model
    def log_closing_printed_ticket(self, session_id, image_base64, printer_name='', status='success'):
        """Archives the visual snapshot of the Cash Closing thermal report."""
        session = self.browse(session_id)
        if not session.exists():
            return False
        ticket_name = f"{session.name} - Cash Closing (Z-Report)"
        ticket = self.env['pos.printed.ticket'].create({
            'name': ticket_name,
            'session_id': session.id,
            'order_id': False,
            'printer_name': printer_name or 'QZ Tray',
            'print_type': 'closing',
            'receipt_snapshot': image_base64,
            'status': status or 'success',
        })
        return {
            'success': True,
            'ticket_id': ticket.id,
        }

    def action_view_printed_tickets(self):
        self.ensure_one()
        return {
            'name': _('Printed Tickets & Closing Reports'),
            'res_model': 'pos.printed.ticket',
            'view_mode': 'tree,form',
            'domain': [('session_id', '=', self.id)],
            'context': {'default_session_id': self.id},
            'type': 'ir.actions.act_window',
        }
