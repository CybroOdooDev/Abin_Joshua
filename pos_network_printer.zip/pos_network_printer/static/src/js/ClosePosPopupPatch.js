/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { ClosePosPopup } from "@point_of_sale/app/navbar/closing_popup/closing_popup";
import { PosStore } from "@point_of_sale/app/store/pos_store";
import { useService } from "@web/core/utils/hooks";
import { _t } from "@web/core/l10n/translation";
import { parseFloat } from "@web/views/fields/parsers";
import { CashClosingReceipt } from "./CashClosingReceipt";
import { qzPrinterService } from "./QZPrinterService";
import { captureThermalReceipt } from "./ThermalReceiptHelper";

patch(ClosePosPopup.prototype, {
    setup() {
        super.setup(...arguments);
        this.renderer = useService("renderer");
        this.notification = useService("notification");
        this.pos.cashClosingPrintHandler = () => this.printCashClosingReport();
        this.pos.isClosingSession = false;

        const originalOrmCall = this.orm.call.bind(this.orm);
        this.orm.call = async (model, method, args, kwargs) => {
            const result = await originalOrmCall(model, method, args, kwargs);
            if (model === "pos.session" && method === "close_session_from_ui") {
                if (result && result.successful) {
                    this.pos.isClosingSession = true;
                } else {
                    this.pos.isClosingSession = false;
                }
            }
            return result;
        };
    },

    /**
     * Prints the Cash Closing Report either as an 80mm thermal receipt or A4 PDF,
     * dynamically fetching all payment methods and CashSecurity balances.
     */
    async printCashClosingReport() {
        try {
            const config = this.pos.config;
            const printerType = config.cash_closing_printer_type || "receipt";

            // If cash control is active, persist current counted cash so data is 100% current
            if (this.pos.config.cash_control && this.props.default_cash_details?.id) {
                const countedVal = this.state.payments[this.props.default_cash_details.id]?.counted;
                if (countedVal && this.env.utils.isValidFloat(countedVal)) {
                    await this.orm.call("pos.session", "post_closing_cash_details", [
                        this.pos.pos_session.id,
                        parseFloat(countedVal),
                    ]);
                }
            }

            // Fetch session closing report data
            const reportData = await this.orm.call(
                "pos.session",
                "get_cash_closing_report_data",
                [this.pos.pos_session.id]
            );

            if (!reportData) {
                throw new Error(_t("Could not retrieve session closing report data."));
            }

            // Generate receipt HTML element
            const receiptEl = await this.renderer.toHtml(CashClosingReceipt, {
                data: reportData,
                formatCurrency: this.env.utils.formatCurrency,
                currentDate: new Date().toLocaleString(),
            });

            if (!receiptEl) {
                throw new Error(_t("Failed to generate thermal receipt element."));
            }

            // Capture thermal receipt raster image for QZ Tray and Ticket History
            let imageBase64 = null;
            try {
                imageBase64 = await captureThermalReceipt(receiptEl);
            } catch (snapErr) {
                console.warn("Error capturing thermal receipt snapshot:", snapErr);
            }

            const printerDisplayName = printerType === "a4" ? "A4 Printer (PDF)" : (
                (config.qz_printer_id && config.qz_printer_id[1]) ||
                config.qz_printer_name ||
                config.printer_name ||
                "Receipt Printer"
            );

            // Always archive visual snapshot to pos.printed.ticket so it appears in Ticket History
            if (imageBase64 && imageBase64.length > 50) {
                try {
                    await this.orm.call("pos.session", "log_closing_printed_ticket", [
                        this.pos.pos_session.id,
                        imageBase64,
                        printerDisplayName,
                        "success",
                    ]);
                } catch (archiveErr) {
                    console.warn("Could not archive closing ticket snapshot:", archiveErr);
                }
            }

            // 1. A4 Printer Output
            if (printerType === "a4") {
                await this.report.doAction(
                    "pos_network_printer.action_report_pos_cash_closing",
                    [this.pos.pos_session.id]
                );
                this.notification?.add(
                    _t("A4 Cash Closing Report generated and archived to Ticket History"),
                    { type: "success" }
                );
                return true;
            }

            // 2. Receipt Printer Output (QZ Tray / POS Printer)
            if (config.enable_network_printing) {
                if (!imageBase64 || imageBase64.length < 50) {
                    throw new Error(_t("Failed to render thermal receipt image snapshot."));
                }

                if (config.simulation_mode) {
                    console.log("[Simulation Mode] Cash closing report saved to Ticket History (physical print skipped).");
                    this.notification?.add(
                        _t("Cash Closing Report saved to Ticket History (Simulation Mode: physical print skipped)"),
                        { type: "info" }
                    );
                } else {
                    const printResult = await qzPrinterService.printReceiptImage(
                        imageBase64,
                        printerDisplayName
                    );
                    this.notification?.add(
                        _t("Cash Closing Report printed via QZ Tray (%s)", printResult.printer_name || "Receipt Printer"),
                        { type: "success" }
                    );
                }
                return true;
            }

            // Fallback: standard hardware proxy printer or browser print
            if (this.hardwareProxy && this.hardwareProxy.printer) {
                await this.hardwareProxy.printer.printReceipt(receiptEl);
                this.notification?.add(_t("Cash Closing Report printed via POS printer"), { type: "success" });
                return true;
            }

            // Fallback: browser print window
            const printWindow = window.open("", "_blank", "width=400,height=600");
            if (printWindow) {
                printWindow.document.write("<html><head><title>Cash Closing Report</title></head><body>");
                printWindow.document.write(receiptEl.outerHTML);
                printWindow.document.write("</body></html>");
                printWindow.document.close();
                printWindow.focus();
                printWindow.print();
                printWindow.close();
            }
            return true;
        } catch (err) {
            console.error("Error printing Cash Closing Report:", err);
            this.notification?.add(
                _t("Error printing Cash Closing Report: %s", err.message || err),
                { type: "danger" }
            );
            return false;
        }
    },
});

patch(PosStore.prototype, {
    redirectToBackend() {
        if (this.isClosingSession && this.config && this.config.auto_print_cash_closing && this.cashClosingPrintHandler) {
            this.isClosingSession = false;
            const printPromise = Promise.resolve(this.cashClosingPrintHandler());
            const timeoutPromise = new Promise((resolve) => setTimeout(resolve, 5000));
            Promise.race([printPromise, timeoutPromise])
                .catch((err) => {
                    console.error("Auto-print error before redirect:", err);
                })
                .finally(() => {
                    super.redirectToBackend();
                });
            return;
        }
        super.redirectToBackend();
    },
});
