/** @odoo-module **/

import { Order, Orderline } from "@point_of_sale/app/store/models";
import { PosStore } from "@point_of_sale/app/store/pos_store";
import { Orderline as OrderlineComponent } from "@point_of_sale/app/generic_components/orderline/orderline";
import { ProductScreen } from "@point_of_sale/app/screens/product_screen/product_screen";
import { patch } from "@web/core/utils/patch";
import { useService } from "@web/core/utils/hooks";
import { PlatingLevelPopup } from "@pos_kitchen_display/js/plating_level_popup";
import { PlatingLevelSelector } from "@pos_kitchen_display/js/plating_level_selector";

// Register PlatingLevelSelector in ProductScreen components
ProductScreen.components = {
    ...ProductScreen.components,
    PlatingLevelSelector,
};

// Patch PosStore to process loaded pos.plating.level data
patch(PosStore.prototype, {
    async _processData(loadedData) {
        await super._processData(...arguments);
        this.pos_plating_level = loadedData["pos.plating.level"] || [];
        this.pos_plating_level_by_id = {};
        for (const level of this.pos_plating_level) {
            this.pos_plating_level_by_id[level.id] = level;
        }
    },
});

// Patch Orderline Model
patch(Orderline.prototype, {
    setup() {
        super.setup(...arguments);
        this.plating_level_id = this.plating_level_id || null;
    },

    export_as_JSON() {
        const json = super.export_as_JSON(...arguments);
        json.plating_level_id = this.plating_level_id || false;
        return json;
    },

    init_from_JSON(json) {
        super.init_from_JSON(...arguments);
        this.plating_level_id = json.plating_level_id || null;
    },

    get_plating_level() {
        if (!this.pos?.config?.enable_plating_level || !this.plating_level_id) return null;
        const levels = this.pos.pos_plating_level || [];
        return levels.find(l => l.id === this.plating_level_id) || null;
    },

    set_plating_level(levelId) {
        this.plating_level_id = levelId || null;
    },

    can_be_merged_with(orderline) {
        if (this.plating_level_id !== orderline.plating_level_id) {
            return false;
        }
        return super.can_be_merged_with(...arguments);
    },

    getDisplayData() {
        const data = super.getDisplayData(...arguments);
        data.plating_level_id = this.plating_level_id;
        data.plating_level = this.get_plating_level();
        return data;
    },
});

// Patch Order Model
patch(Order.prototype, {
    setup() {
        super.setup(...arguments);
        this.selected_plating_level_id = undefined;
    },

    export_as_JSON() {
        const json = super.export_as_JSON(...arguments);
        json.selected_plating_level_id = this.selected_plating_level_id;
        return json;
    },

    init_from_JSON(json) {
        super.init_from_JSON(...arguments);
        this.selected_plating_level_id = json.selected_plating_level_id;
    },

    get_default_plating_level_id() {
        if (!this.pos?.config?.enable_plating_level) return null;
        const levels = this.pos?.pos_plating_level || [];
        const defaultRec = levels.find(l => l.is_default);
        return defaultRec ? defaultRec.id : null;
    },

    get_selected_plating_level_id() {
        if (this.selected_plating_level_id === undefined) {
            this.selected_plating_level_id = this.get_default_plating_level_id();
        }
        return this.selected_plating_level_id;
    },

    set_selected_plating_level(levelId) {
        this.selected_plating_level_id = levelId || null;
    },

    set_orderline_options(orderline, options) {
        const res = super.set_orderline_options(...arguments);
        if (!this.pos?.config?.enable_plating_level) {
            return res;
        }
        if (options && options.plating_level_id !== undefined) {
            orderline.set_plating_level(options.plating_level_id);
        } else if (!orderline.plating_level_id) {
            // Inherit from combo parent or use order's active course
            const levelId = options?.comboParent?.plating_level_id || this.get_selected_plating_level_id();
            if (levelId) {
                orderline.set_plating_level(levelId);
            }
        }
        return res;
    },
});

// Patch Orderline OWL Component for line-level course change
patch(OrderlineComponent.prototype, {
    setup() {
        super.setup(...arguments);
        this.popup = useService("popup");
        this.pos = useService("pos");
    },

    async changePlatingLevel(line) {
        if (!this.pos?.config?.enable_plating_level) return;
        await this.popup.add(PlatingLevelPopup, { line });
    },
});
