# -- coding: utf-8 --
#############################################################################
#
#    Cybrosys Technologies Pvt. Ltd.
#
#    Copyright (C) 2026-TODAY Cybrosys Technologies(<https://www.cybrosys.com>)
#    Author: Cybrosys Techno Solutions(<https://www.cybrosys.com>)
#
#    You can modify it under the terms of the GNU LESSER
#    GENERAL PUBLIC LICENSE (LGPL v3), Version 3.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU LESSER GENERAL PUBLIC LICENSE (LGPL v3) for more details.
#
#    You should have received a copy of the GNU LESSER GENERAL PUBLIC LICENSE
#    (LGPL v3) along with this program.
#    If not, see <http://www.gnu.org/licenses/>.
#
#############################################################################
{
    "name": "POS Kitchen Display",
    "version": "17.0.1.14.18",
    "category": "Point of Sale",
    "depends": ["agr_kiosk_pay", "pos_kiosk_enhancements", "pos_restaurant", "bus", "mail", "point_of_sale", "stock_sms", "web", "website"],
    "data": [
        'security/res_groups.xml',
        'security/ir.model.access.csv',
        'data/kitchen_display_data.xml',
        'data/pos_plating_level_data.xml',
        'views/kitchen_display_views.xml',
        'views/pos_plating_level_views.xml',
        'views/pos_config_views.xml',
        'views/kitchen_display_template.xml',
    ],
    "assets": {
        "pos_kitchen_display.assets_kds": [
            ("include", "web._assets_helpers"),
            "web/static/src/scss/pre_variables.scss",
            "web/static/lib/bootstrap/scss/_variables.scss",
            ("include", "web._assets_bootstrap"),
            ("include", "web._assets_core"),
            "bus/static/src/bus_parameters_service.js",
            "bus/static/src/multi_tab_service.js",
            "bus/static/src/services/bus_service.js",
            "bus/static/src/workers/websocket_worker.js",
            "bus/static/src/workers/websocket_worker_script.js",
            "bus/static/src/workers/websocket_worker_utils.js",
            "pos_kitchen_display/static/src/css/kitchen_display.css",
            "pos_kitchen_display/static/src/app/kitchen_service.js",
            "pos_kitchen_display/static/src/app/kitchen_app.js",
            "pos_kitchen_display/static/src/app/kitchen_app.xml",
            "pos_kitchen_display/static/src/components/stage.js",
            "pos_kitchen_display/static/src/components/stage.xml",
            "pos_kitchen_display/static/src/components/order_card.js",
            "pos_kitchen_display/static/src/components/order_card.xml",
            "pos_kitchen_display/static/src/components/order_line.js",
            "pos_kitchen_display/static/src/components/order_line.xml",
        ],
        'pos_self_order.assets':[
            'pos_kitchen_display/static/src/js/order_widget.js',
            'pos_kitchen_display/static/src/js/kiosk_confirm_popup.js',
            'pos_kitchen_display/static/src/js/kiosk_confirm_popup.xml',
        ],
        'point_of_sale._assets_pos': [
            'pos_kitchen_display/static/src/css/plating_level.css',
            'pos_kitchen_display/static/src/js/kitchen_notification.js',
            'pos_kitchen_display/static/src/js/reminder_control_button.js',
            'pos_kitchen_display/static/src/js/reminder_control_button.xml',
            'pos_kitchen_display/static/src/js/kitchen_reminder_popup.js',
            'pos_kitchen_display/static/src/js/kitchen_reminder_popup.xml',
            'pos_kitchen_display/static/src/js/order.js',
            'pos_kitchen_display/static/src/js/ActionpadWidget.js',
            'pos_kitchen_display/static/src/js/table.js',
            'pos_kitchen_display/static/src/js/table.xml',
            'pos_kitchen_display/static/src/js/plating_level_popup.js',
            'pos_kitchen_display/static/src/js/plating_level_popup.xml',
            'pos_kitchen_display/static/src/js/plating_level_selector.js',
            'pos_kitchen_display/static/src/js/plating_level_selector.xml',
            'pos_kitchen_display/static/src/js/pos_order_plating_level.js',
            'pos_kitchen_display/static/src/js/orderline_plating_level.xml',
            'pos_kitchen_display/static/src/js/appetizer_selection_popup.js',
            'pos_kitchen_display/static/src/js/appetizer_selection_popup.xml',
            'pos_kitchen_display/static/src/js/pos_combo_resume.js',
            'pos_kitchen_display/static/src/js/pos_combo_resume.xml',
        ],
        "web.assets_backend": [
            "pos_kitchen_display/static/src/backend/kitchen_backend_notification.js",
            "pos_kitchen_display/static/src/sounds/kitchenorder_notification.wav",
            "pos_kitchen_display/static/src/sounds/reminder.wav",
            "pos_kitchen_display/static/src/sounds/waiter_alert.wav"
        ],
    },
    "installable": True,
    "auto_install": False,
    "license": "LGPL-3",
}
